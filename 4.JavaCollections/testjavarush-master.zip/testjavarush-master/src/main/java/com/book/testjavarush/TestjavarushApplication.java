package com.book.testjavarush;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestjavarushApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestjavarushApplication.class, args);
    }
}
